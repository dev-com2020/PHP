<?php
header('Location:http://localhost/dashboard/notes/view/view.php');
?>